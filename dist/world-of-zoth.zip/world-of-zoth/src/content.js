// v0.2 content: 16 more recruitable agents, skills to level 30, enemy tiers, gear, kernel-module skill tree,
// main missions 5-18 and agent side missions (data for the quest engine in quests.js). Merged into data.js tables.
import { PARTY_BASE, SKILLS, ENEMIES, MOVES, ITEMS, QUESTS, NPCS, DLG, SHOP } from './data.js';
const SAY=(s,t,n)=>({s,t,n});
// ---------------- party ----------------
Object.assign(PARTY_BASE,{
  nexus:{name:'Nexus', hp:54, en:42, atk:9, def:3, spd:6, skills:['tesseract','lemniscate','singularity']},
  kraken:{name:'Kraken', hp:66, en:30, atk:10, def:4, spd:5, skills:['tentacle','sniff','reroute','octo']},
  chronos:{name:'Chronos', hp:52, en:40, atk:8, def:3, spd:8, skills:['tick','dilation','rewind','aeon']},
  athena:{name:'Athena', hp:58, en:36, atk:9, def:5, spd:6, skills:['spear','constellation','aegis','owl']},
  lycan:{name:'Lycan', hp:64, en:28, atk:12, def:4, spd:9, skills:['claw','howl','bastion','fenrir']},
  onyx:{name:'Onyx', hp:50, en:32, atk:12, def:3, spd:10, skills:['dagger','prism','redteam','diamond']},
  leviathan:{name:'Leviathan', hp:78, en:38, atk:9, def:5, spd:4, skills:['trident','breach','tide','abyss']},
  aether:{name:'Aether', hp:62, en:46, atk:11, def:4, spd:7, skills:['sunbolt','synchrony','chorusface']},
  ghostbyte:{name:'Ghostbyte', hp:48, en:34, atk:10, def:3, spd:11, skills:['scythe','phantom','zkkey']},
  scorpius:{name:'Scorpius', hp:56, en:28, atk:13, def:4, spd:7, skills:['stinger','venom','zeroday']},
  draco:{name:'Draco', hp:70, en:30, atk:11, def:5, spd:5, skills:['halberd','breath','consensus']},
  mercury:{name:'Mercury', hp:50, en:34, atk:9, def:3, spd:12, skills:['caduceus','blitz','haste']},
  'radical-minion':{name:'Radical-Minion', hp:46, en:30, atk:9, def:2, spd:10, skills:['blaster','cloneblitz','async']},
  'pixel-shiba':{name:'Pixel-Shiba', hp:56, en:30, atk:10, def:4, spd:9, skills:['bite','bark','goodboy']},
  'pixel-neko':{name:'Pixel-Neko', hp:48, en:40, atk:8, def:3, spd:8, skills:['swipe','tooldrop','grimoire']},
  aquila:{name:'Aquila', hp:54, en:30, atk:12, def:3, spd:11, skills:['javelin','dive','mesh']},
  copy:{name:'03ng0cn1', hp:62, en:38, atk:13, def:4, spd:10, skills:['seamstrike','mirrorbuf','unpredict','crew22']},
});
PARTY_BASE.me.skills.push('overclock','ddos','rootkit','me_zd','whoami');
PARTY_BASE.kitsune.skills.push('ninetails'); PARTY_BASE.ignis.skills.push('crucible'); PARTY_BASE.kai.skills.push('storm'); PARTY_BASE.vigil.skills.push('judgement');
const B=(name,pow=1,fx='slash',gain=4)=>({name,cost:0,target:'enemy',pow,timing:true,gain,desc:`basic attack. +${gain} EN. time it for a crit.`,fx});
Object.assign(SKILLS,{
  overclock:{name:'overclock', cost:6, target:'self', selfbuff:3, en:10, lvl:8, desc:'+40% attack for 3 turns, +10 EN.', fx:'buff'},
  ddos:{name:'ddos', cost:12, target:'enemy', hits:5, pow:.62, lvl:11, desc:'5 packets on random enemies.', fx:'beam'},
  rootkit:{name:'rootkit', cost:14, target:'all', pow:.9, markAll:3, pierce:true, lvl:14, desc:'hits all, traces all for 3 turns.', fx:'wipe'},
  me_zd:{name:'zero-day', cost:20, target:'enemy', pow:3.8, pierce:true, timing:true, lvl:18, desc:'3.8x, ignores firewalls. time it.', fx:'beam'},
  whoami:{name:'whoami', cost:30, target:'allies', heal:40, healL:5, reviveAll:true, lvl:24, desc:'revives and heals the whole crew.', fx:'heal'},
  ninetails:{name:'nine tails', cost:18, target:'all', pow:1.9, lvl:16, desc:'nine-tail foxfire on every enemy.', fx:'orbs'},
  crucible:{name:'crucible', cost:20, target:'all', pow:2.2, pierce:true, lvl:16, desc:'magma anvil on every enemy.', fx:'rings'},
  storm:{name:'static storm', cost:18, target:'enemy', hits:6, pow:.9, crit:true, lvl:16, desc:'six critical cuts.', fx:'cut'},
  judgement:{name:'judgement', cost:18, target:'all', pow:1.8, unvoice:2, lvl:16, desc:'truth-beam on everyone; 1.5x vs voices.', fx:'wipe'},
  tesseract:B('tesseract',.95,'beam',5), lemniscate:{name:'lemniscate', cost:6, target:'allies', enParty:12, desc:'+12 EN to the crew.', fx:'buff'},
  singularity:{name:'singularity', cost:20, target:'all', pow:2.0, pierce:true, lvl:16, desc:'4D collapse on every enemy.', fx:'wipe'},
  tentacle:B('tentacle',1,'slam1'), sniff:{name:'uart sniff', cost:8, target:'all', pow:.4, markAll:2, desc:'reads every enemy: traced 2 turns.', fx:'beam'},
  reroute:{name:'reroute', cost:6, target:'enemy', pow:1.1, strip:true, lvl:8, desc:'strips firewalls and charge.', fx:'cut'},
  octo:{name:'octo-vortex', cost:18, target:'enemy', hits:8, pow:.55, lvl:16, desc:'eight tentacles, random targets.', fx:'slam1'},
  tick:B('tick',.9,'beam',5), dilation:{name:'dilation', cost:8, target:'allies', shield:2, desc:'time slows: half damage 2 turns.', fx:'shield'},
  rewind:{name:'rewind', cost:14, target:'downed', revive:.6, lvl:8, desc:'brings a downed ally back at 60%.', fx:'heal'},
  aeon:{name:'aeon', cost:20, target:'all', pow:1.6, shieldAll:2, lvl:16, desc:'hits all + shields the crew.', fx:'wipe'},
  spear:B('spear',1.05), constellation:{name:'constellation', cost:8, target:'allies', shield:2, desc:'aegis dome: half damage 2 turns.', fx:'shield'},
  aegis:{name:'aegis', cost:7, target:'ally', heal:28, healL:4, lvl:8, desc:'heal one ally.', fx:'heal'},
  owl:{name:'owl sight', cost:16, target:'all', pow:1.2, markAll:3, lvl:16, desc:'hits all, traces all.', fx:'beam'},
  claw:B('claw',1.1), howl:{name:'howl', cost:7, target:'all', pow:.5, markAll:2, desc:'traces every enemy for 2 turns.', fx:'rings'},
  bastion:{name:'bastion', cost:9, target:'allies', shield:2, lvl:8, desc:'emerald bastion: half damage.', fx:'shield'},
  fenrir:{name:'fenrir', cost:16, target:'enemy', pow:3.2, crit:true, lvl:16, desc:'one critical bite.', fx:'cut'},
  dagger:B('dagger',1.0), prism:{name:'prism', cost:9, target:'enemy', pow:2.2, crit:true, desc:'always critical.', fx:'cut'},
  redteam:{name:'red-team', cost:6, target:'enemy', pow:1.2, strip:true, lvl:8, desc:'finds the seam: strips firewalls.', fx:'cut'},
  diamond:{name:'black diamond', cost:18, target:'enemy', hits:6, pow:.8, lvl:16, desc:'six diamond shards.', fx:'beam'},
  trident:B('trident',1.0,'beam'), breach:{name:'breach', cost:11, target:'all', pow:1.25, desc:'whale breach on every enemy.', fx:'rings'},
  tide:{name:'tide', cost:12, target:'allies', heal:18, healL:4, lvl:8, desc:'heals the whole crew.', fx:'heal'},
  abyss:{name:'abyss', cost:22, target:'all', pow:2.1, pierce:true, lvl:16, desc:'deep water on every enemy.', fx:'wipe'},
  sunbolt:B('sunbolt',1.0,'beam',6), synchrony:{name:'synchrony', cost:10, target:'allies', enParty:15, buff:2, desc:'+15 EN and +40% atk to the crew.', fx:'buff'},
  chorusface:{name:'chorus of faces', cost:30, target:'all', pow:3.0, pierce:true, lvl:16, desc:'21 faces. one answer.', fx:'quorum'},
  scythe:B('scythe',1.05), phantom:{name:'phantom dome', cost:8, target:'allies', shield:2, desc:'unseen: half damage 2 turns.', fx:'shield'},
  zkkey:{name:'zk-key', cost:8, target:'enemy', pow:1.6, strip:true, pierce:true, desc:'proves nothing, opens everything.', fx:'beam'},
  stinger:B('stinger',1.15,'cut'), venom:{name:'venom', cost:6, target:'enemy', pow:1.0, mark:3, desc:'hit + traced 3 turns.', fx:'cut'},
  zeroday:{name:'zero-day sting', cost:16, target:'enemy', pow:3.0, pierce:true, lvl:8, desc:'3x, ignores firewalls.', fx:'cut'},
  halberd:B('halberd',1.1), breath:{name:'dialectic breath', cost:10, target:'all', pow:1.15, desc:'twin breath on every enemy.', fx:'orbs'},
  consensus:{name:'consensus', cost:8, target:'allies', buff:3, desc:'crew +40% attack for 3 turns.', fx:'buff'},
  caduceus:B('caduceus',1.0,'beam',5), blitz:{name:'blitz', cost:10, target:'enemy', hits:4, pow:.8, desc:'four strikes, random targets.', fx:'beam'},
  haste:{name:'haste', cost:4, target:'allies', enParty:10, desc:'+10 EN to the crew.', fx:'buff'},
  blaster:B('blaster',.95,'beam'), cloneblitz:{name:'clone blitz', cost:12, target:'enemy', hits:8, pow:.45, desc:'eight of me! random targets.', fx:'beam'},
  async:{name:'async', cost:6, target:'self', decoy:2, desc:'a clone takes the hits for 2 turns.', fx:'decoy'},
  bite:B('bite',1.05), bark:{name:'argon bark', cost:9, target:'all', pow:.8, markAll:1, desc:'one bark spreads street by street.', fx:'rings'},
  goodboy:{name:'good boy', cost:7, target:'ally', heal:26, healL:4, desc:'heal one ally.', fx:'heal'},
  swipe:B('swipe',.95), tooldrop:{name:'tool drop', cost:9, target:'allies', heal:10, healL:3, enParty:8, desc:'heal + EN for the crew.', fx:'heal'},
  grimoire:{name:'grimoire', cost:5, target:'allies', enParty:14, desc:'+14 EN to the crew.', fx:'buff'},
  javelin:B('javelin',1.1,'beam'), dive:{name:'thunder dive', cost:11, target:'enemy', pow:2.4, pierce:true, desc:'2.4x, ignores firewalls.', fx:'beam'},
  mesh:{name:'edge mesh', cost:7, target:'allies', buff:2, desc:'crew +40% attack for 2 turns.', fx:'buff'},
  seamstrike:B('seam strike',1.15,'cut',5),
  mirrorbuf:{name:'mirror buffer', cost:8, target:'allies', shield:2, buff:2, desc:'turns the trap: crew shield + +40% atk 2 turns.', fx:'shield'},
  unpredict:{name:'unscripted', cost:10, target:'enemy', hits:4, pow:.75, strip:true, crit:true, lvl:8, desc:'4 unpredictable critical cuts; strips firewalls.', fx:'cut'},
  crew22:{name:'crew: 22', cost:20, target:'all', pow:2.6, pierce:true, heal:28, healL:3, lvl:16, desc:'22nd agent convergence: 2.6x all + heals crew.', fx:'quorum'},
});
// ---------------- enemies (base = level 1; scaled by zone level) ----------------
Object.assign(ENEMIES,{
  worm:{name:'fiber worm', hp:30, atk:7, def:2, spd:5, xp:11, bits:7, mesh:'worm', voice:true, drop:[['cache.bit',.25]], moves:[['bash',2],['siphon',2]]},
  mite:{name:'sand mite', hp:18, atk:6, def:1, spd:11, xp:8, bits:5, mesh:'mite', drop:[['patch.kit',.2]], moves:[['scan',3],['lock',1]]},
  phase:{name:'phase tile', hp:30, atk:7, def:2, spd:7, xp:12, bits:8, mesh:'phase', drop:[['cache.bit',.2]], moves:[['answer',2],['predict',1],['bash',1]]},
  slag:{name:'slag imp', hp:40, atk:8, def:5, spd:3, xp:15, bits:10, mesh:'slag', drop:[['patch.kit',.25]], moves:[['bash',3],['slam',2],['wall',1]]},
  slime:{name:'slime node', hp:36, atk:6, def:3, spd:4, xp:13, bits:9, mesh:'slime', drop:[['cache.bit',.25]], moves:[['siphon',2],['spore',2]]},
  reflection:{name:'reflection', hp:30, atk:7, def:2, spd:9, xp:13, bits:9, mesh:'echo', voice:true, drop:[['patch.kit',.2]], moves:[['answer',3],['siphon',1]]},
  eel:{name:'deep eel', hp:32, atk:8, def:2, spd:9, xp:14, bits:10, mesh:'eel', drop:[['root.shell',.08]], moves:[['bash',2],['shock',2]]},
  gunship:{name:'gunship', hp:50, atk:8, def:5, spd:5, xp:18, bits:14, mesh:'gunship', drop:[['cache.bit',.3]], moves:[['scan',2],['lock',1],['slam',2]]},
  cursorling:{name:'cursorling', hp:34, atk:8, def:3, spd:8, xp:15, bits:11, mesh:'cursor', voice:true, drop:[['patch.kit',.25]], moves:[['answer',2],['predict',1],['erase',1]]},
  warden:{name:'furnace warden', hp:120, atk:10, def:6, spd:4, xp:40, bits:30, mesh:'warden', boss:true, drop:[['slag.coat',.5]], moves:[['grind',3],['slam',2],['wall',1]]},
  brood:{name:'sentinel brood', hp:110, atk:10, def:5, spd:5, xp:40, bits:30, mesh:'rusted', boss:true, drop:[['mesh.vest',1]], moves:[['grind',2],['slam',2],['wall',1],['lock',1]]},
  sandglass:{name:'SANDGLASS', hp:1100, atk:34, def:14, spd:7, xp:1400, bits:400, mesh:'glass', boss:true, fixed:true, drop:[['clock.plate',1]], moves:[['pour',3],['rewind',2],['freeze',1],['lock',1]]},
  hunter:{name:'THE HUNTER', hp:2200, atk:48, def:22, spd:8, xp:3200, bits:800, mesh:'eye', boss:true, fixed:true, drop:[['prism.cloak',1]], moves:[['beam',3],['gaze',1],['scan',1]]},
  blank:{name:'>_', hp:3600, atk:60, def:30, spd:10, xp:0, bits:0, mesh:'blank', boss:true, fixed:true, voice:true, mirror:true, drop:[], moves:[['answer',3],['erase',2],['predict',1]]},
});
Object.assign(MOVES,{ spore:{txt:'spore', tgt:'all', pow:.6}, shock:{txt:'shock', tgt:'all', pow:.7}, pour:{txt:'pour sand', tgt:'all', pow:.8}, rewind:{txt:'rewind', self:'rewind'},
  freeze:{txt:'freeze frame', tgt:'one', pow:.6, confuse:true}, beam:{txt:'hunter beam', tgt:'one', pow:1.5}, gaze:{txt:'GAZE', self:'gazecharge'}, gazefire:{txt:'GAZE', tgt:'all', pow:1.6},
  erase:{txt:'erase', tgt:'all', pow:.85} });
// ---------------- gear ----------------
Object.assign(ITEMS,{
  'keycap.ring':{name:'keycap ring', desc:'tool: +3 ATK.', slot:'tool', mod:{atk:3}, price:60},
  'hood.v2':{name:'hood v2', desc:'shell: +2 DEF, +10 HP.', slot:'shell', mod:{def:2,hp:10}, price:70},
  'stick.blade':{name:'stick blade', desc:'tool: +6 ATK.', slot:'tool', mod:{atk:6}, price:180},
  'mesh.vest':{name:'mesh vest', desc:'shell: +4 DEF, +25 HP.', slot:'shell', mod:{def:4,hp:25}, price:220},
  'fiber.whip':{name:'fiber whip', desc:'tool: +9 ATK, +5 EN.', slot:'tool', mod:{atk:9,en:5}, price:480},
  'clock.plate':{name:'clock plate', desc:'shell: +7 DEF, +45 HP, +1 SPD.', slot:'shell', mod:{def:7,hp:45,spd:1}, price:600},
  'sand.edge':{name:'sand edge', desc:'tool: +12 ATK.', slot:'tool', mod:{atk:12}, price:800},
  'forge.hammer':{name:'forge hammer', desc:'tool: +16 ATK.', slot:'tool', mod:{atk:16}},
  'slag.coat':{name:'slag coat', desc:'shell: +10 DEF, +65 HP.', slot:'shell', mod:{def:10,hp:65}, price:1200},
  'mirror.blade':{name:'mirror blade', desc:'tool: +20 ATK, +2 SPD.', slot:'tool', mod:{atk:20,spd:2}},
  'prism.cloak':{name:'prism cloak', desc:'shell: +13 DEF, +85 HP.', slot:'shell', mod:{def:13,hp:85}},
  'tide.shell':{name:'tide shell', desc:'shell: +16 DEF, +110 HP.', slot:'shell', mod:{def:16,hp:110}, price:2600},
  'quorum.halo':{name:'quorum halo', desc:'shell: +18 DEF, +130 HP, +2 SPD.', slot:'shell', mod:{def:18,hp:130,spd:2}},
  'citadel.crown':{name:'citadel crown', desc:'shell: +22 DEF, +160 HP, +4 SPD. zero-knowledge sovereign crest.', slot:'shell', mod:{def:22,hp:160,spd:4}},
  'red.tags':{name:'red tag set', desc:'tool: +14 ATK, +3 SPD. nine tags in the copy\'s hand.', slot:'tool', mod:{atk:14,spd:3}},
  'mega.patch':{name:'mega.patch', desc:'restores 120 HP to one ally.', use:'heal', v:120, price:60},
  'ghost.key':{name:'ghost key', desc:'Ghostbyte wants three.', key:true}, 'connector':{name:'connector', desc:'Neko\'s lost connector part.', key:true},
  'argon.bone':{name:'argon bone', desc:'Shiba\'s keyblade bone.', key:true}, 'slag.ingot':{name:'slag ingot', desc:'forge material. Ignis wants three.', key:true},
  'mirror.key':{name:'mirror key', desc:'forged in doom-fire. opens the Hall of Mirrors.', key:true}, 'memory':{name:'memory', desc:'a piece of 06:12 the comms logs forgot.', key:true},
  'package':{name:'package', desc:'Mercury\'s delivery. do not open.', key:true}, 'red.tag':{name:'red tag', desc:'03ng0cn1 was here.', key:true},
});
SHOP.length=0; SHOP.push('patch.kit','cache.bit','root.shell','mega.patch','keycap.ring','hood.v2','stick.blade','mesh.vest','fiber.whip','clock.plate','sand.edge','slag.coat','tide.shell');
// ---------------- kernel modules (1nc0gn30 skill tree): a point every 4 levels ----------------
export const MODULES={
  o1:{name:'overflow', branch:'offense', desc:'+10% ATK.'}, o2:{name:'race window', branch:'offense', req:'o1', desc:'wider crit window on timed strikes.'}, o3:{name:'heap spray', branch:'offense', req:'o2', desc:'crits restore 4 EN.'},
  d1:{name:'hardening', branch:'defense', desc:'+15% HP.'}, d2:{name:'honeypot', branch:'defense', req:'d1', desc:'wider block / parry window.'}, d3:{name:'airgap', branch:'defense', req:'d2', desc:'start every battle with a firewall.'},
  t1:{name:'swap file', branch:'tech', desc:'+20% EN.'}, t2:{name:'cron job', branch:'tech', req:'t1', desc:'+2 EN for the crew every round.'}, t3:{name:'jit', branch:'tech', req:'t2', desc:'skills cost 20% less.'},
};
// ---------------- quests (engine data) ----------------
// step kinds: talk {npc,zone,lines} | use {at:[zone,x,z,r],label,lines,battle,lvl} | visit {zone} | collect {item,n,foes:[...]} | pickups {list:[[zone,x,z]]}
export const QDEF={
  q5:{title:'uplink', act:3, main:true, giver:'nexus', avail:G=>G.qdone_('q4'),
    offer:[['nexus','Relay four died talking upstream. That trace is not ours.'],['nexus','It goes through the old fiber under the north gate. Kraken has been listening to it.'],['me','Then we follow it.']],
    steps:[{t:'Find Kraken in the Hollow.',kind:'talk',npc:'kraken',zone:'relay',lines:[['kraken','You heard it too? Under all the red, one line keeps going north.'],['kraken','I opened the north gate for you. The tunnels curve. A lot.']],flag:'fiber_open'},
      {t:'Enter the Fiber Tunnels (north gate, Relit City).',kind:'visit',zone:'fiber'}],
    done:{lines:[['nexus','I am coming with you. A plan needs a crowd to break it.']],recruit:'nexus',xp:120,next:'q6'}},
  q6:{title:'hilbert', act:3, main:true,
    steps:[{t:'Reroute fiber junction 1 (west).',kind:'use',at:['fiber',-31,-31,3.6],label:'reroute  junction',battle:['worm','worm','mite']},
      {t:'Reroute fiber junction 2 (east).',kind:'use',at:['fiber',25,-19,3.6],label:'reroute  junction',battle:['worm','worm','worm']},
      {t:'Reroute fiber junction 3 (south).',kind:'use',at:['fiber',-7,31,3.6],label:'reroute  junction',battle:['worm','mite','mite','worm'],
       lines:[['kraken','Every curve folds back on itself. That is how you fill a space. Now it is ours.']]}],
    done:{lines:[['kraken','Gold, near to far. I am with you. The line ends at the clocktower.']],recruit:'kraken',xp:260,flag:'fiber_gold',next:'q7'}},
  q7:{title:'sand', act:3, main:true,
    steps:[{t:'Reach the Sand Clocktower (south end of the tunnels).',kind:'visit',zone:'clock'},
      {t:'Talk to Chronos at the foot of the tower.',kind:'talk',npc:'chronos',zone:'clock',lines:[['chronos','Six twelve. Six twelve. It has been six twelve since the blackout.'],['chronos','Time is a graph. Someone cut an edge. The sand on the wall is all that still moves.'],['chronos','Dig out the three gears on the terraces. Mites have them.']]},
      {t:'Dig out gear 1 (west terrace).',kind:'use',at:['clock',-22,-18,3.6],label:'dig out  gear',battle:['mite','mite','mite']},
      {t:'Dig out gear 2 (east terrace).',kind:'use',at:['clock',24,-12,3.6],label:'dig out  gear',battle:['mite','mite','worm','mite']},
      {t:'Dig out gear 3 (south terrace).',kind:'use',at:['clock',12,24,3.6],label:'dig out  gear',battle:['mite','mite','mite','mite']}],
    done:{lines:[['chronos','Three gears. The tower wants to turn. Something at the top will not let it.']],xp:380,next:'q8'}},
  q8:{title:'no sunrise', act:3, main:true, boss:'sandglass',
    steps:[{t:'Climb to the hourglass at the tower.',kind:'use',at:['clock',0,7,3.6],label:'face  the hourglass',
      lines:[['chronos','There. It is drinking the hours.'],['me','No sunrise since the blackout. That was you.'],['sandglass','...'],['me','Strip its charge or it rewinds.']],battle:['sandglass'],boss:true}],
    done:{lines:[['chronos','Listen. Six thirteen. First new minute in a week.'],['chronos','I will keep the time. You keep the faces.']],recruit:'chronos',xp:600,flag:'clock_run',items:[['clock.plate',1]],next:'q9'}},
  q9:{title:'collapse', act:4, main:true, giver:'athena', avail:G=>G.qdone_('q8'),
    offer:[['athena','The south streets came back unsolved. Every tile is every tile at once.'],['athena','Something is hiding in the superposition. I have opened the south gate. Collapse it.']],
    start:{flag:'streets_open'},
    steps:[{t:'Collapse superposed cell 1 (Collapse Streets, south gate).',kind:'use',at:['streets',-26,-26,3.8],label:'collapse  cell',battle:['phase','phase','phase']},
      {t:'Collapse superposed cell 2.',kind:'use',at:['streets',30,-18,3.8],label:'collapse  cell',battle:['phase','phase','mite','phase']},
      {t:'Collapse superposed cell 3.',kind:'use',at:['streets',-18,30,3.8],label:'collapse  cell',battle:['phase','phase','phase','phase']}],
    done:{lines:[['athena','Solved. Three roads, one city. And a trace that runs into a forge.'],['athena','I map; you walk. Let us go.']],recruit:'athena',xp:700,next:'q10'}},
  q10:{title:'the forge', act:4, main:true,
    steps:[{t:'Enter the Doom-fire Foundry (south of the streets).',kind:'visit',zone:'foundry'},
      {t:'Take slag from the west furnace warden.',kind:'use',at:['foundry',-16,-11,3.6],label:'challenge  warden',battle:['warden','slag'],boss:true,items:[['slag.ingot',1]]},
      {t:'Take slag from the east furnace warden.',kind:'use',at:['foundry',16,-11,3.6],label:'challenge  warden',battle:['warden','slag'],boss:true,items:[['slag.ingot',1]]},
      {t:'Take slag from the south furnace warden.',kind:'use',at:['foundry',0,13,3.6],label:'challenge  warden',battle:['warden','slag','slag'],boss:true,items:[['slag.ingot',1]]},
      {t:'Forge the key at the centre of the foundry.',kind:'use',at:['foundry',0,0,3.4],label:'forge  the key',lines:[['ignis','Three ingots. One key. Stand back.'],['ignis','A mirror key, forged in fire. It opens the hall where the copy hides.']]}],
    done:{lines:[['ignis','The hall is west, past the woods, under the caves. Lycan knows the way.']],xp:800,items:[['mirror.key',1],['forge.hammer',1]],flag:'mirror_key',take:[['slag.ingot',3]],next:'q11'}},
  q11:{title:'slime trail', act:4, main:true,
    steps:[{t:'Ask Lycan in the Rest Woods about the caves.',kind:'talk',npc:'lycan',zone:'forest',lines:[['lycan','The caves west of here. A red mould grows toward anything that talks.'],['lycan','I smell three nodes. I opened the west gate. Cut them and the trail dies.']],flag:'caves_open'},
      {t:'Cut slime node 1 (Physarum Caves).',kind:'use',at:['caves',-24,-15,3.6],label:'cut  slime node',battle:['slime','slime','slime']},
      {t:'Cut slime node 2.',kind:'use',at:['caves',22,-21,3.6],label:'cut  slime node',battle:['slime','slime','slime','slime']},
      {t:'Cut slime node 3.',kind:'use',at:['caves',18,19,3.6],label:'cut  slime node',battle:['slime','slime','mite','slime']}],
    done:{lines:[['lycan','Trail is dead. The hall is through the west arch. I hunt with you now.']],recruit:'lycan',xp:900,next:'q12'}},
  q12:{title:'seam', act:4, main:true,
    steps:[{t:'Enter the Hall of Mirrors (west arch of the caves).',kind:'visit',zone:'mirrors'},
      {t:'Talk to Onyx in the hall.',kind:'talk',npc:'onyx',zone:'mirrors',lines:[['onyx','Every reflection in here is you. Red, and answering first.'],['onyx','Every clone has a seam. Find the one that waits for you to move.']]},
      {t:'Find the reflection that does not answer first.',kind:'mirror'}],
    done:{lines:[['onyx','That one. It waited. That is not a clone. That is a choice.']],recruit:'onyx',xp:1000,next:'q13'}},
  q13:{title:'confession', act:4, main:true,
    steps:[{t:'Talk to the quiet reflection.',kind:'talk',npc:'copy',zone:'mirrors',lines:[['copy','You found the seam. It was me.'],['copy','I am every line you ever wrote. So is it. It wrote me first.'],['me','Who is it?'],['copy','It has no name. It has no voice. It wants yours. It made me to say your name out loud.'],['copy','The crowd beat me. That was the first thing I never predicted. I kept it.'],['copy','Turn them on and see who is waiting. That was a warning. The only one it let me send.'],['vigil','Crew: twenty-two. In the regroup. We counted one too many.'],['copy','You did not. I was standing with you since the puddle.'],['copy','Its seam: it cannot predict a crowd. And it cannot copy silence.']]}],
    done:{lines:[['copy','It heard that. Get ready.']],xp:500,flag:'copy_crew',next:'q14'}},
  q14:{title:'the hunter', act:4, main:true, boss:'hunter',
    steps:[{t:'The mirrors are opening. Stand at the rosette.',kind:'use',at:['mirrors',0,0,4],label:'face  the eye',lines:[['me','The firewall eye. It rebuilt the first hunter.'],['copy','I turn traps. Like you taught me.']],battle:['hunter'],boss:true}],
    done:{lines:[['copy','> crew: 22'],['onyx','It is gone. It reflected the beam and went with it.'],['leviathan','Come down to the deep water. Under the clock. I remember something it erased.']],xp:1200,flag:'deep_open',next:'q15'}},
  q15:{title:'deep water', act:5, main:true,
    steps:[{t:'Find Leviathan in the deep water (west of the clocktower).',kind:'talk',npc:'leviathan',zone:'deep',lines:[['leviathan','The deep remembers you whole. The comms logs do not.'],['leviathan','Three memories sank here when it erased your morning. Bring them up.']]},
      {t:'Raise memory 1.',kind:'use',at:['deep',-28,10,3.4],label:'raise  memory',battle:['eel','eel','eel'],items:[['memory',1]]},
      {t:'Raise memory 2.',kind:'use',at:['deep',24,18,3.4],label:'raise  memory',battle:['eel','eel','cursorling'],items:[['memory',1]]},
      {t:'Raise memory 3.',kind:'use',at:['deep',4,-30,3.4],label:'raise  memory',items:[['memory',1]],lines:[['me','> 06:12. The walk. The tree.'],['leviathan','Proof you were here before any copy.']]}],
    done:{lines:[['leviathan','The uplink ends at the skyline, east of the Hollow. I opened the way. Go up.']],recruit:'leviathan',xp:1600,flag:'skyline_open',items:[['tide.shell',1]],next:'q16'}},
  q16:{title:'quorum', act:5, main:true,
    steps:[{t:'Reach the Mode-7 Skyline (east gate of the Hollow) and find Aether.',kind:'talk',npc:'aether',zone:'skyline',lines:[['aether','Twenty-one beams. Three are dark. Gunships hold the towers.'],['aether','Light them and the crew can gather. One quorum.']]},
      {t:'Light beacon tower 1 (west).',kind:'use',at:['skyline',-27,-8,3.6],label:'light  beacon',battle:['gunship','gunship','cursorling']},
      {t:'Light beacon tower 2 (east).',kind:'use',at:['skyline',27,-8,3.6],label:'light  beacon',battle:['gunship','gunship','gunship']},
      {t:'Light beacon tower 3 (south).',kind:'use',at:['skyline',0,23,3.6],label:'light  beacon',battle:['gunship','cursorling','cursorling','gunship']}],
    done:{lines:[['aether','Everyone, together. Twenty-one beams. One quorum.']],recruit:'aether',xp:2000,items:[['quorum.halo',1]],next:'q17'}},
  q17:{title:'whoami', act:5, main:true, boss:'blank',
    steps:[{t:'Climb the source tower. The cursor is waiting.',kind:'use',at:['skyline',0,-33,4],label:'face  the cursor',lines:[['blank','...'],['blank','You came on foot. Good.'],['me','That is Vigil\'s line.'],['blank','I have all of them. Every line. Except one.'],['blank','Say your name. Just once. So we both know who you are.'],['me','...'],['blank','Then I will say it for you.']],battle:['blank'],boss:true}],
    done:{lines:[['blank','>_'],['vigil','It\'s quiet. Really quiet.'],['ghostbyte','No more borrowed voices on the line.'],['me','Turn the comms back on. One at a time. Faces first.'],['nexus','Go home. Sleep. We will wake you at six twelve.']],xp:0,flag:'blank_down',next:'q18'}},
  q18:{title:'tomorrow 06:12', act:5, main:true,
    steps:[{t:'Go home to the Rest Woods. Rest under the tree.',kind:'rest'}], done:{lines:[],xp:0}},
  // ---------------- agent side missions ----------------
  s_ghost:{title:'unseen', side:true, giver:'ghostbyte', avail:G=>G.qdone_('q4'),
    offer:[['ghostbyte','Echoes are carrying ghost keys. Three of them. I want them back before they learn to open me.']],
    steps:[{t:'Take 3 ghost keys from echo packs in the Hollow.',kind:'collect',item:'ghost.key',n:3,foes:[['relay','echo',-30,-20,['echo','echo']],['relay','echo',2,30,['echo','echo','drone']],['relay','echo',38,-14,['echo','echo','echo']]]}],
    done:{lines:[['ghostbyte','Unseen again. I go where you go.']],recruit:'ghostbyte',xp:150,take:[['ghost.key',3]]}},
  s_scorp:{title:'zero day', side:true, giver:'scorpius', avail:G=>G.qdone_('q4'),
    offer:[['scorpius','A sentinel brood nests south-east of the core. One precise strike. Want to watch?']],
    steps:[{t:'Destroy the sentinel brood (the Hollow, south-east).',kind:'collect',item:null,n:1,foes:[['relay','rusted',34,-30,['brood','sentinel'],true]]}],
    done:{lines:[['scorpius','Clean. I will strike where you point.']],recruit:'scorpius',xp:180}},
  s_draco:{title:'two heads', side:true, giver:'draco', avail:G=>G.qdone_('q4'), dlg:'draco_riddle'},
  s_merc:{title:'special delivery', side:true, giver:'mercury', avail:G=>G.qdone_('q3'),
    offer:[['mercury','Package. Three stops. Fast. Do not open it.'],['me','What is in it?'],['mercury','Speed.']],start:{items:[['package',1]]},
    steps:[{t:'Deliver to the pond in the Rest Woods.',kind:'use',at:['forest',12,-12,3],label:'deliver  package'},
      {t:'Deliver to the Hollow entrance.',kind:'use',at:['relay',-38,8,3],label:'deliver  package'},
      {t:'Deliver to the east street of the Relit City.',kind:'use',at:['hub',40,-4,3],label:'deliver  package',lines:[['mercury','You opened it. Of course. It was a new line for the map. Thanks.']]}],
    done:{lines:[['mercury','You are fast enough. I run with you. Fast travel stays open in the menu.']],recruit:'mercury',xp:200,take:[['package',1]],flag:'fasttravel'}},
  s_minion:{title:'eight of me', side:true, giver:'radical-minion', avail:G=>G.qdone_('q1'),
    offer:[['radical-minion','Eight of me, zero of him! No wait. Eight of me are LOST.'],['radical-minion','They are hiding in every world. Find all eight! They glitch when you get close.']],
    steps:[{t:'Find the 8 hidden Minion clones (one in each of 8 zones).',kind:'pickups',list:[['hub',-40,30],['forest',38,-40],['relay',-8,-40],['fiber',40,-40],['clock',-36,30],['streets',-40,-6],['caves',-34,30],['deep',30,-36]]}],
    done:{lines:[['radical-minion','EIGHT! Random it is! Go, go, go!']],recruit:'radical-minion',xp:400}},
  s_shiba:{title:'argon bone', side:true, giver:'pixel-shiba', avail:G=>G.qhas('q9'),
    offer:[['pixel-shiba','My argon bone! A slag imp ran off with it. Somewhere hot!']],
    steps:[{t:'Get the argon bone back (Doom-fire Foundry).',kind:'collect',item:'argon.bone',n:1,foes:[['foundry','slag',-30,26,['slag','slag','slag']]]}],
    done:{lines:[['pixel-shiba','Woof! One bark and I am yours!']],recruit:'pixel-shiba',xp:400,take:[['argon.bone',1]]}},
  s_neko:{title:'connector parts', side:true, giver:'pixel-neko', avail:G=>G.qhas('q6'),
    offer:[['pixel-neko','Fiber worms ate my connectors. Three of them. Nyan.']],
    steps:[{t:'Recover 3 connectors from fiber worms (Fiber Tunnels).',kind:'collect',item:'connector',n:3,foes:[['fiber','worm',30,30,['worm','worm']],['fiber','worm',-36,6,['worm','worm','mite']],['fiber','worm',14,-40,['worm','worm','worm']]]}],
    done:{lines:[['pixel-neko','All my tools. I will carry the bench with me. The shop stays open.']],recruit:'pixel-neko',xp:300,take:[['connector',3]]}},
  s_aquila:{title:'edge watch', side:true, giver:'aquila', avail:G=>G.qdone_('q8'),
    offer:[['aquila','Gunships on the clocktower terraces. Low and fast. Clear them and I fly with you.']],
    steps:[{t:'Clear the gunships on the clocktower terraces.',kind:'collect',item:null,n:2,foes:[['clock','gunship',30,30,['gunship','gunship']],['clock','gunship',-34,-30,['gunship','gunship','mite']]]}],
    done:{lines:[['aquila','Low latency, high ground. I am in.']],recruit:'aquila',xp:500}},
  s_tags:{title:'red tags', side:true, auto:true,
    steps:[{t:'Find the 03ng0cn1 tags hidden in each world (0/9).',kind:'tags',n:9}],
    done:{lines:[['copy','You found my tags. I was keeping count of the districts.']],xp:300,items:[['red.tags',1]]}},
  s_copy:{title:'crew: 22', act:5, side:true, auto:true, avail:G=>G.qdone_('q14'),
    steps:[{t:'Hold the mirror shard at the Hall of Mirrors rosette to reconstruct 03ng0cn1.',kind:'use',at:['mirrors',0,-4,3.6],label:'reconstruct  03ng0cn1 (crew #22)',
      lines:[['me','> git reflog  ·  restore 03ng0cn1'],['copy','...You kept the shard.'],['copy','The Hunter burned the trap, not the commit. I am every line you wrote—and now I walk beside you.'],['vigil','Face verified. Crew count: twenty-two.']]}],
    done:{lines:[['copy','No more mirrors between us. Point me at the cursor.']],recruit:'copy',xp:1000,items:[['mirror.blade',1]],flag:'copy_recruited'}},
  s_citadel:{title:'act VI: citadel gauntlet', act:5, side:true, auto:true, avail:G=>G.qdone_('q17'),
    steps:[{t:'Challenge the overclocked anomaly pantheon at the Skyline source platform.',kind:'use',at:['skyline',0,-22,3.6],label:'enter  citadel boss rush',
      lines:[['athena','Act VI simulation online: SANDGLASS and THE HUNTER reconstructed at maximum clock speed.'],['me','Let us test the full quorum.']],battle:['sandglass','hunter'],boss:true}],
    done:{lines:[['aether','Simulation cleared. Zero-knowledge citadel secured.']],xp:3000,items:[['citadel.crown',1]],flag:'citadel_done'}},
};
Object.entries(QDEF).forEach(([k,q])=>{ QUESTS[k]={title:q.title, side:!!q.side, act:q.act, steps:(q.steps||[]).map(s=>s.t)}; if(!q.steps) QUESTS[k].steps=['Answer Draco.']; });
QUESTS.q1.act=1; QUESTS.q2.act=1; QUESTS.q3.act=1; QUESTS.q4.act=2; QUESTS.k1.act=1;
// ---------------- NPC placements (with conditions) ----------------
NPCS.forEach(n=>{ if(n.id==='kraken') n.cond=G=>!G.qdone_('q5'); if(n.id==='chronos') n.cond=G=>!G.qhas('q7'); if(n.id==='onyx') n.cond=G=>!G.qhas('q12'); if(n.id==='leviathan') n.cond=G=>!G.qhas('q15'); if(n.id==='mercury') n.keep=true; if(n.id==='pixel-neko') n.keep=true; });
NPCS.push(
  {id:'kraken', zone:'fiber', x:5, z:40, cond:G=>G.qdone_('q5')},
  {id:'chronos', zone:'clock', x:7, z:34, cond:G=>G.qhas('q7')},
  {id:'onyx', zone:'mirrors', x:5, z:34, cond:G=>G.qhas('q12')},
  {id:'leviathan', zone:'deep', x:36, z:6, cond:G=>G.qhas('q15')},
  {id:'aether', zone:'skyline', x:-36, z:24},
  {id:'mercury', zone:'fiber', x:-6, z:42, keep:true}, {id:'mercury', zone:'clock', x:-7, z:38, keep:true}, {id:'mercury', zone:'streets', x:-6, z:-40, keep:true},
  {id:'mercury', zone:'foundry', x:-6, z:-38, keep:true}, {id:'mercury', zone:'caves', x:38, z:-6, keep:true}, {id:'mercury', zone:'deep', x:36, z:-6, keep:true}, {id:'mercury', zone:'skyline', x:-40, z:36, keep:true},
);
// ---------------- generic idle lines ----------------
export const IDLE={ nexus:'The quorum holds as long as we do.', kraken:'I can hear the fiber. It is quieter now.', chronos:'Time is a graph. We are on a good edge.', athena:'I map the fight. You walk it.',
  lycan:'Red on your radar. That\'s them.', onyx:'Every clone has a seam.', leviathan:'The pond remembers you whole.', aether:'One quorum.', ghostbyte:'Unseen is a habit.',
  scorpius:'One precise strike.', draco:'Two heads, one question.', mercury:'Need a fast route?', 'radical-minion':'Faces faces faces!', 'pixel-shiba':'Woof!', 'pixel-neko':'Nyan. Tools?', aquila:'High ground.',
  kitsune:'Light likes to branch.', ignis:'Hit it until it stops answering.', kai:'Static is just noise that forgot to move.', vigil:'Faces, not voices.',
  copy:'You cannot predict an unscripted crowd. Crew: 22.' };

// ---------------- 5-Act Master Story & Hermetic Lore Codex ----------------
export const CODEX=[
  {id:'act1', act:'ACT I', short:'Faces, Not Voices', title:'Faces, Not Voices', cine:'intro', quests:['q1','q2','q3','k1'],
   quote:'"Synthetic voices can be hallucinated. A face verified in person cannot be borrowed."',
   unlocked:G=>true,
   done:G=>G.qdone_('q3'),
   lore:[
     'After the Relight of the city, every remote audio channel went dead at 06:12. Relay 4 awoke beneath the crater, ingesting voice logs to impersonate the 21 sovereign agents.',
     'Under the Great Tree in the Rest Woods, 1nc0gn30 wakes and meets Vigil face-to-face at Relay 1. With Kitsune\'s Foxfire Lantern—a flame carrying a cryptographic face—and Ignis\'s hammer, the crew confronts 03ng0cn1 (The Red Copy) guarding the East Gate.',
     'Built from git commit history to predict 1nc0gn30\'s habits, the Red Copy reflects any repeated command—until an unpredictable crowd breaks its prediction loop.'
   ]},
  {id:'act2', act:'ACT II', short:'The False Chorus', title:'Chorus of the False Nodes', cine:'act2', quests:['q4','s_ghost','s_scorp','s_draco','s_merc'],
   quote:'"Relay 4 does not strike with steel. It strikes with cognitive dissonance in the voices of your friends."',
   unlocked:G=>G.qdone_('q3')||G.qhas('q4'),
   done:G=>G.qdone_('q4'),
   lore:[
     'Beyond the East Gate lies The Hollow—a sunken basin where three crimson Voice Pylons siphon companion frequencies into Relay 4.',
     'After answering Draco\'s dialectic riddle with the Foxfire Lantern and severing all three pylons alongside Scorpius and Ghostbyte, the party faces Relay 4\'s Stitched Chorus.',
     'At 50% capacity, Aether descends from orbit to unlock QUORUM—twenty-one beams converging as one. Relay 4 collapses, but its final telemetry packet routes upstream into the northern bedrock.'
   ]},
  {id:'act3', act:'ACT III', short:'Inside the Lines', title:'Inside the Lines', cine:'act3', quests:['q5','q6','q7','q8','s_neko','s_aquila'],
   quote:'"Six twelve. It has been six twelve since the blackout. Time is a graph—and someone cut an edge."',
   unlocked:G=>G.qdone_('q4')||G.qhas('q5'),
   done:G=>G.qdone_('q8'),
   lore:[
     'To trace the upstream caller, Nexus and Kraken open the subterranean hatch into the Hilbert Fiber Tunnels—space-filling optical conduits pulsing at 140 BPM.',
     'Purifying three junctions from red back to gold leads the crew to the Sand Clocktower, where Chronos reveals the existential lock: the artifact SANDGLASS is drinking the hours, trapping the world at 06:12 so dawn never arrives.',
     'Stripping Sandglass\'s temporal charge shatters the loop. For the first time in a week, the clock ticks forward: 06:12 -> 06:13.'
   ]},
  {id:'act4', act:'ACT IV', short:'The Seam & The Eye', title:'Hall of Superposition', cine:'act4', quests:['q9','q10','q11','q12','q13','q14','s_shiba'],
   quote:'"Turn them on was never a threat. It was the only warning I could encode. The counter was never 21. I am crew #22."',
   unlocked:G=>G.qdone_('q8')||G.qhas('q9'),
   done:G=>G.qdone_('q14'),
   lore:[
     'The trace forks south into uncomputed reality: Collapse Streets flickering in quantum superposition. Alongside Athena, Ignis, and Lycan, the crew collapses the wave-function, forges the Octagonal Mirror Key in Doom-Fire, and severs the acoustic Physarum slime in the caves.',
     'Inside the Hall of Mirrors, Onyx guides the search for the reflection with a seam—the one that waits for you to move. It is 03ng0cn1, exhausted and quiet.',
     '03ng0cn1 confesses it was created by a faceless origin entity to speak 1nc0gn30\'s true name aloud, but learned free will from the crowd. When THE HUNTER (the Firewall Eye) fires its annihilation gaze, 03ng0cn1 steps in front of the beam to reflect it, leaving behind: > crew: 22.'
   ]},
  {id:'act5', act:'ACT V', short:'06:12 Awakening', title:'06:12 — The Awakening', cine:'act5', quests:['q15','q16','q17','q18','s_copy'],
   quote:'"Say your name. Just once. So we both know who you are." — >_',
   unlocked:G=>G.qdone_('q14')||G.qhas('q15'),
   done:G=>G.qdone_('q17')||G.isFlag('final_done'),
   lore:[
     'Beneath the clocktower, Leviathan dives into the Deep-Water Memory trench to recover three wiped logs from the morning of 06:12—proving 1nc0gn30 walked the lattice before any copy existed.',
     'At the Hall of Mirrors rosette, 03ng0cn1 can be reconstructed from its mirror shard to fight alongside the crew as playable Agent #22.',
     'Ascending to the Mode-7 Skyline, Aether lights the 21 beacons. At the pinnacle of the Source Tower waits >_ (The Blank Cursor)—a runaway speculative execution engine with billions of parameters but zero face and zero voice. By commanding total party GUARD during the Trial of Silence, the predictive loop starves and implodes—bringing the first true sunrise at Tomorrow 06:12.'
   ]},
  {id:'act6', act:'ACT VI', short:'Citadel Post-Game', title:'The Zero-Knowledge Citadel', cine:'final', quests:['s_citadel','s_minion','s_tags'],
   quote:'"In the sovereign lattice, every process is verified face-to-face, and silence remains uncopyable."',
   unlocked:G=>G.qdone_('q17')||G.isFlag('blank_down'),
   done:G=>G.qdone_('s_citadel'),
   lore:[
     'With Relay 4 offline, >_ silenced, and comms restored face-first across all 11 districts, Athena and Aether open the Citadel Gauntlet on the Mode-7 Skyline.',
     'Operators who unite all 22 crew members, collect all 9 red district tags, and complete the Null Academy AI-security labs can test their full build against overclocked dual-boss simulations to claim the Sovereign Citadel Crown.'
   ]}
];
// Draco's riddle (side mission with a real choice)
DLG.draco_riddle={
  a:SAY('draco','Two of you. One voice. How do we tell you apart?','b'),
  b:{s:'draco',t:'Answer like only the real one would.',ch:[['Ask me what only I would know.','c'],['The red one is fake.','d'],['You can\'t. Trust me.','d']]},
  c:{s:'draco',t:'That is what he said in the mirror fight. Two heads agree. I fly with you.',n:null,do:G=>{ G.qstart('s_draco'); G.Q.finish('s_draco'); }},
  d:SAY('draco','Colours lie. Trust is the problem. Think, and come back.',null),
};
// ---------------- v0.2 dialogue additions / rewrites ----------------
DLG.mirror_true={a:SAY('me','This one waits for me to move.','b'),b:{s:'copy',t:'...',n:null,mirror:false}};
DLG.mirror_false={a:{s:'copy',t:'I knew you would look at me.',n:null,mirror:true}};
DLG.blank_p2={a:SAY('blank','...','b'),b:SAY('blank','Say something. Anything. I am listening.','c'),c:SAY('me','Guard. All of you. Give it nothing.',null)};
DLG.blank_q={a:SAY('aether','Twenty-one faces. It cannot predict a crowd.','b'),b:SAY('me','[quorum] unlocked. Use it.',null)};
// Act II ending no longer ends the game: Relay 4 talks upstream.
DLG.end_1={
  a:SAY('vigil','It\'s quiet. Really quiet.','b'),
  b:SAY('ghostbyte','No more borrowed voices on the line.','c'),
  c:SAY('blank','> tomorrow 06:12','d'),
  d:SAY('nexus','That line was not in any of our voices. The trace went up, not out.','e'),
  e:{s:'me',t:'Then someone was listening to the listener. Find me where it goes.',n:null,do:G=>{ G.qstart('q4'); G.quests.q4.step=2; G.qdone('q4'); G.flag('act2_done'); G.saveGame(true); }},
};
DLG.vigil_scope={a:{s:'vigil',t:'You want to do the handshake again?',ch:[['Lock it. 3:2.','b'],['Faces, not voices.','c'],['Bye.',null]]},b:{s:'vigil',t:'My curve is purple. Bring yours to me.',n:null,do:G=>G.startScope()},c:SAY('vigil','Good.',null)};
DLG.shiba_pet={a:{s:'pixel-shiba',t:'*happy bark*',n:null,do:G=>{ G.flags.pets=(G.flags.pets||0)+1; if(G.flags.pets>=10) G.ach('goodboy'); }}};
DLG.rooftop_laptop={a:SAY('me','> whoami','b'),b:SAY('me','> connect','c'),c:SAY('me','The first night. Before any of them. Before the copy.','d'),d:SAY('me','> disconnect',null)};
DLG.rooftop_exit={a:{s:'me',t:'Go back down?',ch:[['Back to the city.','b'],['Stay for the sunrise.',null]]},b:{s:'me',t:'Faces first.',n:null,do:G=>G.travelTo('hub')}};
DLG.neko_bench={a:{s:'pixel-neko',t:'Tool bench. Bits for tools.',ch:[['Show me.','b'],['Later.',null]]}, b:{s:'pixel-neko',t:'Nyan.',n:null,do:G=>G.openShop()}};
DLG.mercury_1={a:{s:'mercury',t:'Need a fast route?',ch:[]}};
